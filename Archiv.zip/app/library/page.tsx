'use client';

import { Library } from '@/components/Library';

export default function LibraryPage() {
  return (
    <>
      <div className="flex-1 overflow-auto">
        <Library />
      </div>
    </>
  );
} 